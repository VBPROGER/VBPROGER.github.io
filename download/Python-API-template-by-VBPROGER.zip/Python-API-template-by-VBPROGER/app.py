#!/usr/bin/python3

# Настройка и константы

os = __import__('os')
LIB_METADATA={
    'LIB_NAME': 'Моё имя для библиотеки', # Можете поменять тут всё на своё :-)
    'LIB_VERSION': '1.0.0', # Версия для библиотеки
    'LIB_AUTHOR': 'VBPROGER', # Вы можете ТОЖЕ можете поменять тут имя на своё :)
}

# ...

def MyFunction(Argument1, *ANYARGS): # Не советую удалять где-нибудь "*ANYARGS", если вы не разбираетесь, что это.
    print(Argument1)
def IntToString(MyInt, *ANYARGS): # Та же ситуация.
    if type(MyInt).__name__ == 'int' or type(MyInt).__name__ == 'float':
        return str(MyInt)
    else:
        Type = str(type(MyInt).__name__)
        raise ValueError('Требовался номер / летающее число, в итоге получил: ' + Type)
def MyTestingFunction(*ANYARGS):
    print('Тест: '+IntToString(1))
def HelloOS(*ANYARGS):
    os.system('echo "Hello, OS!"\n')
def MyVersion(*ANYARGS): # Команда вывода версии этой библиотеки
    print(LIB_METADATA['LIB_VERSION'])
    return LIB_METADATA['LIB_VERSION']
def MyName(*ANYARGS): # Команда вывода имени этой библиотеки
    print(LIB_METADATA['LIB_NAME'])
    return LIB_METADATA['LIB_NAME']
def MyAuthor(*ANYARGS): # Команда вывода автора этой библиотеки
    print(LIB_METADATA['LIB_AUTHOR'])
    return LIB_METADATA['LIB_AUTHOR']