#!/usr/bin/python3
import os

__data__ = 'os.', 'save-type'
Libraries = ['os'] # Добавьте / удалите / и т.д. / и т.п тут библиотеки, которые понадобятся для модуля

for lib in Libraries:
    lib = str(lib)
    try:
        exec('import '+lib)
    except BaseException:
        os.system('pip install '+lib)

if __name__ == '__main__':
    if __data__ != '0>NUL': # Без комментариев...
        import app