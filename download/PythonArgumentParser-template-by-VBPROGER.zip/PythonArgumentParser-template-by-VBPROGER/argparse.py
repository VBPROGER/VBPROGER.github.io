#!/usr/bin/python3
from sys import argv as argparser # Импортируем спец. библиотеку
try:
    GetValue=str(argparser[1]); # Получение данных
    print(GetValue) # Вывод данных на экран
except BaseException:
    print('usage: '+str(argparser[0])+' <value>'); # Вывод usage-а, если неправильно
